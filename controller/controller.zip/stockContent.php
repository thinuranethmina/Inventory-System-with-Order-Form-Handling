<?php

require "util/userStatus.php";

if (User::is_allow()) {
    $product_rs = Database::search("SELECT * FROM `product` INNER JOIN `stock` ON `stock`.`product_id` = `product`.`id` WHERE `status_id`= '1' ");
?>
    <div class="col-12 mb-4">
        <h1>Products Stock</h1>
    </div>
    <?php
    while ($product = $product_rs->fetch_assoc()) {
    ?>
        <div class="col-12 col-sm-6 col-xl-4 col-xxl-3 bg-white rounded rounded-5 p-2 tooltips">
            <a href="order-history.php?pid=<?= $product['id'] ?>&deliver=0&status=0">
                <div class="tooltiptext">
                    <div class="text-center">
                        <b><?= $product['model_no'] ?></b>
                    </div>
                    <?= $product['details'] ?>
                </div>
            </a>
            <div class=" p-3 rounded rounded-5 card-border <?php if ($product['qty'] <= $product['warning_no']) {
                                                                echo "stock-warning";
                                                            }  ?> ">
                <div class=" d-flex align-self-center">
                    <img src="<?= $product['cover_image'] ?>" class="rounded rounded-3 card-img">
                    <div class="pl-3">
                        <h4 class=""><?= $product['model_no'] ?></h4>
                    </div>
                </div>
                <div class="d-flex">
                    <div class="mt-auto mb-0 w-100">
                        <div class="d-flex justify-content-between mt-2">
                            <h5 class="my-auto d-inline-block">Primary Stock</h5>
                            <h5 class="my-auto card-count"><?= $product['qty'] ?></h5>
                        </div>
                        <div class="d-flex justify-content-between my-1">
                            <h5 class="my-auto d-inline-block">Ongoing Stock</h5>
                            <h5 class="my-auto card-count"><?= $product['ongoing_qty'] ?></h5>
                        </div>
                        <div class="d-flex justify-content-between">
                            <h5 class="my-auto d-inline-block">Deliver Pending Qty</h5>
                            <h5 class="my-auto card-count"><?= $product['deliver_pending_qty'] ?></h5>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between">
                            <h5 class="my-auto d-inline-block">Stock Summery</h5>
                            <?php $summery = $product['qty'] + $product['ongoing_qty'] - $product['deliver_pending_qty'] ?>
                            <h5 class="my-auto card-count <?= $summery <= 0 ? "text-danger fw-bold" : '' ?>">
                                <?= $summery ?>
                            </h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php
    }
} else {
    echo "reload";
}
